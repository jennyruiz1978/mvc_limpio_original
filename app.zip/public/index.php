<?php
// Carganos el loader.php de la carpeta app
require_once('../app/loader.php');

// instanciar la clase controlador
$iniciar = new Core();