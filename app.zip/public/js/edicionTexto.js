$(document).ready(function () {
    $('#summernote').summernote({
        height: 500, // set editor height
        placeholder: "Introducir el contenido para el plan de negocio"
       // minHeight: null, // set minimum height of editor
       // maxHeight: null, // set maximum height of editor
       // focus: true                  // set focus to editable area after initializing summernote);
    }); // fin del summernote
}); // fin del ready

 //     $('#summernote').summernote({//
//        placeholder: 'Hello Bootstrap 4',
//        tabsize: 2,
//        height: 100
//      });
 