    $(document).ready(function () {
                $("#boton-izquierdo").on('click', function () {

                    $("#sidebar-izquierdo").toggle();
                });

            });


