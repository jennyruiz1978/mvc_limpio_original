<?php
// Configuracion de acceso a la base de datos
define('DB_HOST','185.92.246.83');
define('DB_USUARIO','admin_mvc');
define('DB_PASSWORD','admin_mvc2020$');
define('DB_NOMBRE','admin_mvc');

// Ruta de la aplicacion
define('RUTA_APP', dirname(dirname(__FILE__)));

define('RUTA_URL','http://localhost/mvc_limpio_original');
// NOMBRE DEL SITIO
define('NOMBRE_SITIO', 'MVC ORIGINAL');

//Ruta para subida de ficheros:
define("DOCUMENTOS_PRIVADOS", RUTA_APP."/documentos/");
