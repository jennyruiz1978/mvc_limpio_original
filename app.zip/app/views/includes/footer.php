
<script type="text/javascript" src="<?php echo RUTA_URL ?>/public//js/main.js"></script>

<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="<?php echo RUTA_URL; ?>/public/vendor/components/jquery/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="<?php echo RUTA_URL; ?>/public/vendor/twbs/bootstrap/dist/js/bootstrap.min.js"></script>

<scrip src="<?php echo RUTA_URL; ?>/public/vendor/fortawesome/font-awesome/js/all.min.js"></scrip>
<!-- summernote -->
<script src="<?php echo RUTA_URL; ?>/public/summernote/summernote-bs4.js"></script>
<script type="text/javascript" src="<?php echo RUTA_URL ?>/public/js/edicionTexto.js"></script>
<!-- efecto mostrar ocultar videotutorial -->
<script type="text/javascript" src="<?php echo RUTA_URL ?>/public/js/videoTutorial.js"></script>
<!-- sidebarhover -->
<script type="text/javascript" src="<?php echo RUTA_URL ?>/public/js/sidebarhover.js"></script>
<script type="text/javascript" src="<?php echo RUTA_URL ?>/public/js/sidebarIzquierdo.js"></script>
<!-- interior paginas con ajax -->
<script type="text/javascript" src="<?php echo RUTA_URL ?>/public/js/contenidoPaginas.js"></script>
<!-- Load d3.js and c3.js -->
<script src="<?php echo RUTA_URL ?>/public/node_modules/d3/dist/d3.js" charset="utf-8"></script>
<script src="<?php echo RUTA_URL ?>/public/node_modules/c3/c3.js"></script>
<script type="text/javascript" src="<?php echo RUTA_URL ?>/public/js/vistaInicio.js"></script>



</body>

</html>